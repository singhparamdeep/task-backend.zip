package com.example.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.example.task.models.Task;
import com.example.task.repositories.TaskRepository;

@Service
public class TaskService {

	@Autowired
	TaskRepository todoRepository;

	public List<Task> getAllTodos() {
		Sort sortByCreatedAtDesc = new Sort(Sort.Direction.DESC, "createdAt");
		return todoRepository.findAll(sortByCreatedAtDesc);
	}

	public Task createTodo(Task todo) {
		todo.setCompleted(false);
		return todoRepository.save(todo);
	}

	public ResponseEntity<Task> getTodoById(Long id) {
		return todoRepository.findById(id).map(todo -> ResponseEntity.ok().body(todo))
				.orElse(ResponseEntity.notFound().build());
	}

	public ResponseEntity<Task> updateTodo(Long id, Task todo) {
		return todoRepository.findById(id).map(todoData -> {
			todoData.setTitle(todo.getTitle());
			todoData.setCompleted(todo.getCompleted());
			Task updatedTodo = todoRepository.save(todoData);
			return ResponseEntity.ok().body(updatedTodo);
		}).orElse(ResponseEntity.notFound().build());
	}

	public ResponseEntity<?> deleteTodo(Long id) {
		return todoRepository.findById(id).map(todo -> {
			todoRepository.deleteById(id);
			return ResponseEntity.ok().build();
		}).orElse(ResponseEntity.notFound().build());
	}

}
