import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  tasks = [];

  constructor(public appService: AppService, private router: Router) { }

  ngOnInit() {
    this.loadTasks();
  }

  loadTasks() {
    this.appService.getTasks().subscribe(tasks => (this.tasks = tasks));

  }

  goToAddtaskForm() {
    //  console.log(`Hmmm...we didn't navigate anywhere`);
    this.router.navigate(['/addTask']);

  }

  editTaskByID(id: number) {
    this.router.navigate(['/addTask'], { queryParams: { mode: 'edit', id : id } });
  }

  deleteTaskById(id: number) {
    this.appService.deleteTask(id).subscribe(deleteMessage => this.loadTasks());
  }
}
