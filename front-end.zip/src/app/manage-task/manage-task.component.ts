import { Component, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

// This interface may be useful in the times ahead...
interface Task {
  id: number;
  name: string;
  description: string;
  dueDate: string;
  completed: string;
  status: string;
}

interface Team {
  id: number;
  teamNameName: string;

}

@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.css']
})
export class TaskDetailsComponent implements OnInit, OnChanges, OnDestroy {
  memberModel: Task;
  taskForm: FormGroup;
  submitted = false;
  alertType: String;
  alertMessage: String;
  teams = [];
  id: number;
  private sub: any;
  formTitle: string;



  constructor(private route: ActivatedRoute, private fb: FormBuilder, private appService: AppService, private router: Router) { }

  ngOnInit() {
    this.taskForm = this.fb.group({
      id: [],
      name: ['', Validators.required],
      description: ['', Validators.required],
      dueDate: ['', Validators.required],
      completed: ['', Validators.required],
      status: ['', Validators.required]
    }, {
    });
    this.sub = this.route.queryParams.subscribe(params => {
      this.id = params['id'];
      console.log(this.id);
      if (this.id) {
        this.formTitle = 'Edit User';
        this.appService.getTaskById(this.id).subscribe(result => (this.taskForm.setValue(result)));
      } else {
        this.formTitle = 'Add Task to Racing Team';
      }
    });

    this.appService.getTeams().subscribe(teams => (this.teams = teams));

  }

  get taskFormControl() {
    return this.taskForm.controls;
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
  

  ngOnChanges() { }

  // TODO: Add task to tasks
  onSubmit(form: FormGroup) {
    this.submitted = true;
    if (form.invalid) {
      return;
    }
    this.memberModel = form.value;
    
    this.appService.saveTask(this.memberModel).subscribe(result => (this.router.navigate(['/tasks'])));

  }
}
