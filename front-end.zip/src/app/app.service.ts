import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  api = 'http://localhost:3000';
  username: string;

  constructor(private http: HttpClient) { }

  // Returns all tasks
  getTasks() {
    return this.http
      .get(`${this.api}/tasks`)
      .pipe(catchError(this.handleError));
  }

  getTaskById(id) {
    return this.http
      .get(`${this.api}/tasks/${id}`)
      .pipe(catchError(this.handleError));
  }

  saveTask(task) {
    if(task.id){
      return this.http
      .put(`${this.api}/tasks`, task)
      .pipe(catchError(this.handleError));
    }else {
    return this.http
      .post(`${this.api}/tasks`, task)
      .pipe(catchError(this.handleError));
    }

  }


  editTask(task) {
    return this.http
      .put(`${this.api}/tasks`, task)
      .pipe(catchError(this.handleError));
  }

  deleteTask(id) {
    return this.http
      .delete(`${this.api}/tasks/${id}`)
      .pipe(catchError(this.handleError));
  }


  setUsername(name: string): void {
    this.username = name;
  }

  addTask(taskForm) { }

  getTeams() {
    return this.http
      .get(`${this.api}/teams`)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
    }
    return [];
  }
}
